import java.awt.*;
/* This class holds the game logic and all the winning conditions for the game*/
public class winCondition {
    //var that keeps track of the winner
    public int WhosWinning = -1;
    //checks for the winning conditions in all directions.
    public boolean CheckWinner(int WhosTurn, GameButton[][] ButtonArr) {
        int lastPlayer = (WhosTurn == 1) ? 2 : 1;
        return (CheckWinHorz(lastPlayer, ButtonArr) || CheckWinVert(lastPlayer, ButtonArr) || CheckWinDR(lastPlayer, ButtonArr) || CheckWinDL(lastPlayer, ButtonArr));
    }
    //The board is checked for tie
    public boolean IsDraw(GameButton[][] ButtonArr) {
        for (int x = 0; x < 6; x++) {
            for (int y = 0; y < 7; y++) {
                if (ButtonArr[x][y].getPlayer() == 0) {
                    return false;
                }
            }
        }
        return true;
    }
    //all the vertical rows are being compared to lookout for the winning combination.
    private boolean CheckWinVert(int lastPlayer, GameButton[][] ButtonArr) {
        for (int y = 0; y < 7; y++) {
            int Count = 0;
            for (int x = 0; x < 6; x++) {
                if (ButtonArr[x][y].getPlayer() == lastPlayer) {
                    Count++;
                    if (Count == 4) {
                        ButtonArr[x][y].getStyleClass().clear();
                        ButtonArr[x][y].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                        ButtonArr[x-1][y].getStyleClass().clear();
                        ButtonArr[x-1][y].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                        ButtonArr[x-2][y].getStyleClass().clear();
                        ButtonArr[x-2][y].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                        ButtonArr[x-3][y].getStyleClass().clear();
                        ButtonArr[x-3][y].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                        WhosWinning = lastPlayer;
                        return true;
                    }
                } else {
                    Count = 0;
                }
            }
        }
        return false;
    }

    private boolean CheckWinHorz(int lastPlayer, GameButton[][] ButtonArr) {
        for (int x = 0; x < 6; x++) {
            int Count = 0;
            for (int y = 0; y < 7; y++) {
                if (ButtonArr[x][y].getPlayer() == lastPlayer) {
                    Count++;
                    if (Count == 4) {
                        ButtonArr[x][y].getStyleClass().clear();
                        ButtonArr[x][y].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color: white");
                        ButtonArr[x][y-1].getStyleClass().clear();
                        ButtonArr[x][y-1].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                        ButtonArr[x][y-2].getStyleClass().clear();
                        ButtonArr[x][y-2].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                        ButtonArr[x][y-2].getStyleClass().clear();
                        ButtonArr[x][y-3].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                        WhosWinning = lastPlayer;
                        return true;
                    }
                } else {
                    Count = 0;
                }
            }
        }
        return false;
    }

    private boolean CheckWinDR(int lastPlayer, GameButton[][] ButtonArr) {
        for (int y = 0; y < 7; y++) {
            for (int x = 0; x < 6; x++) {
                int Count = 0;
                int i, j;
                for (i = x, j = y; i < 6 && j < 7; i++,j++) {
                    if (ButtonArr[i][j].getPlayer() == lastPlayer) {
                        Count++;
                        if (Count == 4) {
                            ButtonArr[i][j].getStyleClass().clear();


                            ButtonArr[i][j].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            ButtonArr[i-1][j-1].getStyleClass().clear();
                            ButtonArr[i-1][j-1].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            ButtonArr[i-2][j-2].getStyleClass().clear();
                            ButtonArr[i-2][j-2].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            ButtonArr[i-3][j-3].getStyleClass().clear();
                            ButtonArr[i-3][j-3].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            WhosWinning = lastPlayer;
                            return true;
                        }
                    } else {
                        Count = 0;
                    }
                }
            }
        }
        return false;
    }

    private boolean CheckWinDL(int lastPlayer, GameButton[][] ButtonArr) {
        for (int y = 0; y < 7; y++) {
            for (int x = 0; x < 6; x++) {
                int Count = 0;
                int i, j;
                for (i = x, j = y; i < 6 && j >= 0; i++,j--) {
                    if (ButtonArr[i][j].getPlayer() == lastPlayer) {
                        Count++;
                        if (Count == 4) {
                            ButtonArr[i][j].getStyleClass().clear();
                            ButtonArr[i][j].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            ButtonArr[i-1][j+1].getStyleClass().clear();
                            ButtonArr[i-1][j+1].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            ButtonArr[i-2][j+2].getStyleClass().clear();
                            ButtonArr[i-2][j+2].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            ButtonArr[i-3][j+3].getStyleClass().clear();
                            ButtonArr[i-3][j+3].setStyle("-fx-border-color: #62e805; -fx-border-width: 2px; -fx-background-color:white");
                            WhosWinning = lastPlayer;
                            return true;
                        }
                    } else {
                        Count = 0;
                    }
                }
            }
        }
        return false;
    }
}
