import javafx.animation.PauseTransition;
import javafx.application.Application;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;

import javafx.scene.control.*;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.HashMap;
import java.util.Stack;


public class JavaFXTemplate extends Application {

	int TotalCol, TotalRow, Theme = 0, WhosTurn = 1;
	Button startGame, newGame = new Button("New Game"), exit = new Button("Exit");
	BorderPane Pane;
	VBox GameRoot, OpningRoot, FinishingRoot;
	Text Starting, EndingMsg, txt;
	GridPane GameGrid;
	MenuBar MenuOptions;
	HashMap<String,Scene> AllScenes;
	PauseTransition PauseTrans = new PauseTransition(Duration.seconds(5));
	Stack<int[]> GameMoves = new Stack<>();
	EventHandler<ActionEvent> UsedButtons, MenuPopUps;
	GameButton[][] ButtonArr = new GameButton[6][7];
	Popup ShowUp;
	winCondition win = new winCondition();


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Welcome to Connect4");
		AllScenes = new HashMap<>(); //for storing all the scene

		MenuPopUps =
				e -> {
					if (!ShowUp.isShowing())
						ShowUp.show(primaryStage);
				};

		AllScenes.put("StartScene", StartScene()); //scene one
		AllScenes.put("GameScene", GameScene()); //scene two

		startGame.setOnAction(e -> primaryStage.setScene(AllScenes.get("GameScene")));

		PauseTrans.setOnFinished(e-> primaryStage.setScene(AllScenes.get("FinalScene"))); //scene three

		newGame.setOnAction(e -> {ResetGame(); primaryStage.setScene(AllScenes.get("GameScene"));});
		exit.setOnAction(e -> Platform.exit());

		primaryStage.setScene(AllScenes.get("StartScene"));
		primaryStage.show();
	}
	//keeps the track of the players moves, so players can undo the moves they make in the game
	private void UndoMove() {
		if (!GameMoves.empty()) {
			int tempRow, tempCol;
			tempRow = GameMoves.peek()[0];
			tempCol = GameMoves.peek()[1];
			ButtonArr[tempRow][tempCol].setDisable(false);
			ButtonArr[tempRow][tempCol].SetCheckClicked(false);

			if (Theme == 0) {
				ButtonArr[tempRow][tempCol].SetPlayers(0, "gray");
			} else if (Theme == 1) {
				ButtonArr[tempRow][tempCol].SetPlayers(0, "#006666");
			} else if (Theme == 2) {
				ButtonArr[tempRow][tempCol].SetPlayers(0, "#027DFF");
			}
			GameMoves.pop();
			WhosTurn = (WhosTurn == 1) ? 2 : 1;
			txt.setText("Player " + WhosTurn + " reversed their move at " + tempRow + ", " + tempCol + ". Player " + WhosTurn + " pick again.");
		} else {
			txt.setText("Please make a move first");
		}
	}
	//at any point players can reset the board. empty's the board and restarts the game
	private void ResetGame() {
		for (int x = 0; x < 6; x++) {
			for (int y = 0; y < 7; y++) {
				ButtonArr[x][y].setDisable(false);
				ButtonArr[x][y].SetCheckClicked(false);
				if (Theme == 0) {
					ButtonArr[x][y].SetPlayers(0, "gray");
				} else if (Theme == 1) {
					ButtonArr[x][y].SetPlayers(0, "#006666");
				} else if (Theme == 2) {
					ButtonArr[x][y].SetPlayers(0, "#027DFF");
				}
			}
		}
		txt.setText(null);
		WhosTurn = 1;
		while (!GameMoves.empty()) {
			GameMoves.pop();
		}
	}
	
	public void GameMoves() {
		if (TotalRow == 5 || ButtonArr[TotalRow+1][TotalCol].GetCheckClicked()) {
			txt.setText("Player " + WhosTurn + " moved to " + TotalRow + "," + TotalCol + "\n");
			if (Theme == 0) {
				String color = (WhosTurn == 1) ? "red" : "yellow";
				ButtonArr[TotalRow][TotalCol].SetPlayers(WhosTurn, color);
			} else if (Theme == 1) {
				String color = (WhosTurn == 1) ? "brown" : "pink";
				ButtonArr[TotalRow][TotalCol].SetPlayers(WhosTurn, color);
			} else if (Theme == 2) {
				String color = (WhosTurn == 1) ? "black" : "white";
				ButtonArr[TotalRow][TotalCol].SetPlayers(WhosTurn, color);
			}
			WhosTurn = (WhosTurn == 1) ? 2 : 1;
			ButtonArr[TotalRow][TotalCol].setDisable(true);
			ButtonArr[TotalRow][TotalCol].SetCheckClicked(true);
			GameMoves.push(new int[]{TotalRow, TotalCol});
		} else {
			txt.setText("Player " + WhosTurn + " moved to " + TotalRow + "," + TotalCol + ". This is NOT valid move. Player " + WhosTurn + " pick again.");
		}
	}

	public void DisableBtn() {
		for (int x = 0; x < 6; x++) {
			for (int y = 0; y < 7; y++) {
				ButtonArr[x][y].setDisable(true);
			}
		}
	}

	public void FirstTheme() {
		Theme = 0;
		GameGrid.setStyle("-fx-background-color: #1c2f88;");
		GameRoot.setStyle("-fx-background-color: #373737");
		txt.setFill(Color.GRAY);
		for (int y = 0; y < 7; y++) {
			for (int x = 0; x < 6; x++) {
				if (ButtonArr[x][y].getPlayer() == 0) {
					ButtonArr[x][y].SetPlayers(0, "gray");
				} else if (ButtonArr[x][y].getPlayer() == 1) {
					ButtonArr[x][y].SetPlayers(1, "red");
				} else if (ButtonArr[x][y].getPlayer() == 2) {
					ButtonArr[x][y].SetPlayers(2, "yellow");
				}

			}
		}

	}

	public void SecTheme() {
		Theme = 1;
		GameGrid.setStyle("-fx-background-color: #7f45d7;");
		GameRoot.setStyle("-fx-background-color: #14e8b7");
		txt.setFill(Color.WHITE);

		for (int y = 0; y < 7; y++) {
			for (int x = 0; x < 6; x++) {
				if (ButtonArr[x][y].getPlayer() == 0) {
					ButtonArr[x][y].SetPlayers(0, "#FF5500FF");
				} else if (ButtonArr[x][y].getPlayer() == 1) {
					ButtonArr[x][y].SetPlayers(1, "brown");
				} else if (ButtonArr[x][y].getPlayer() == 2) {
					ButtonArr[x][y].SetPlayers(2, "pink");
				}

			}
		}
	}

	public void ThirdTheme() {
		Theme = 2;
		GameGrid.setStyle("-fx-background-color: #0bc9e3;");
		GameRoot.setStyle("-fx-background-color: #FFFAFA");
		txt.setFill(Color.BLACK);
		for (int y = 0; y < 7; y++) {
			for (int x = 0; x < 6; x++) {
				if (ButtonArr[x][y].getPlayer() == 0) {
					ButtonArr[x][y].SetPlayers(0, "#027DFF");
				} else if (ButtonArr[x][y].getPlayer() == 1) {
					ButtonArr[x][y].SetPlayers(1, "black");
				} else if (ButtonArr[x][y].getPlayer() == 2) {
					ButtonArr[x][y].SetPlayers(2, "white");
				}
			}
		}
	}

	public Scene StartScene() {
		startGame = new Button("Start");
		startGame.setStyle("-fx-background-color: #373737 ;-fx-border-color: #a604ee; -fx-text-fill: #ffd941; -fx-border-width: 5px; -fx-font-size: 20px; -fx-padding: 20 40 20 40; -fx-font-weight: bold;");

		Starting = new Text();
		Starting.setText("Welcome to Connect Four\nEnjoy!!");
		Starting.setFont(Font.font("Helvetica", 18));
		Starting.setFill(Color.GRAY);
		Starting.setTextAlignment(TextAlignment.CENTER);

		OpningRoot = new VBox(20, Starting, startGame);
		OpningRoot.setAlignment(Pos.CENTER);

		Pane = new BorderPane(OpningRoot);

		return new Scene(Pane, 400,350);
	}

	public Scene FinalScene() {
		EndingMsg = new Text();
		newGame.setStyle( "-fx-background-color: rgba(11,201,227,0) ;-fx-border-color: #a604ee; -fx-text-fill: #ff6505; -fx-border-width: 5px; -fx-font-size: 20px; -fx-padding: 20 40 20 40; -fx-font-weight: bold");
		newGame.setMinWidth(100);
		exit.setStyle( "-fx-background-color: rgba(13,227,220,0) ;-fx-border-color: #a604ee; -fx-text-fill: #ff0505; -fx-border-width: 5px; -fx-font-size: 20px; -fx-padding: 20 40 20 40; -fx-font-weight: bold");
		exit.setMinWidth(100);
		if (win.CheckWinner(WhosTurn,ButtonArr)) {
			EndingMsg.setText("Ayyy Player " + win.WhosWinning + " won!!");
			EndingMsg.setStyle("-fx-text-fill: #ffffff");
		} else {
			EndingMsg.setText("Ayy the game is tie");
		}

		EndingMsg.setTextAlignment(TextAlignment.CENTER);
		EndingMsg.setFont(Font.font("Helvetica", 18));
		EndingMsg.setFill(Color.GRAY);
		HBox buttons = new HBox(30, newGame, exit);
		buttons.setAlignment(Pos.CENTER);
		FinishingRoot = new VBox(20, EndingMsg, buttons);
		FinishingRoot.setStyle("-fx-background-color: #373737");
		FinishingRoot.setAlignment(Pos.CENTER);
		BorderPane Pane = new BorderPane(FinishingRoot);
		return new Scene(Pane, 400,350);
	}

	public Scene GameScene() {
		GameGrid = new GridPane();
		txt = new Text();

		txt.setFont(Font.font("Helvetica", 18));
		txt.setFill(Color.GRAY);
		GameGrid.setStyle("-fx-background-color: #1c2f88;");
		GameGrid.setMaxSize(400, 400);
		GameGrid.setPadding(new Insets(10,10,10,10));
		GameGrid.setVgap(5);
		GameGrid.setHgap(5);
		GameGrid.setAlignment(Pos.CENTER);

		ShowUp = new Popup();
		Label howTo = new Label();
		howTo.setFont(new Font(20));
		howTo.setText("Start out by clicking on the buttons row of the board. Each player takes turns to do so.\n" +
				"The Goal for the player is to get four matching colors in a row either horizontally, vertically or diagonally.\n" +
				"If you manage to fill up the board than its a tie.\n" +
				"Click back on the game board to close this ShowUp.");
		howTo.setTextAlignment(TextAlignment.CENTER);
		howTo.setStyle("-fx-background-color: green;");

		ShowUp.getContent().add(howTo);
		ShowUp.setAutoHide(true);
		ShowUp.centerOnScreen();

		UsedButtons = actionEvent -> {
			GameButton Gbutton = (GameButton) actionEvent.getSource();
			TotalRow = Gbutton.getNumRow();
			TotalCol = Gbutton.getNumCol();
			GameMoves();
			if (win.CheckWinner(WhosTurn,ButtonArr)) {
				DisableBtn();
				AllScenes.put("FinalScene", FinalScene());
				PauseTrans.play();
			} else if (win.IsDraw(ButtonArr)) {
				AllScenes.put("FinalScene", FinalScene());
				PauseTrans.play();
			}
		};

		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				GameButton Gbutton = new GameButton(i, j);
				Gbutton.setOnAction(UsedButtons);
				ButtonArr[i][j] = Gbutton;
				GameGrid.add(ButtonArr[i][j], j, i);
			}
		}

		/////////////////grid making it 3d/////////////////////

		Light.Distant light = new Light.Distant();
		light.setAzimuth(45.0);
		light.setElevation(30.0);

		Lighting lighting = new Lighting();
		lighting.setLight(light);
		lighting.setSurfaceScale(5.0);
		GameGrid.setEffect(lighting);

		MenuOptions = new MenuBar();

		Menu gamePlay = new Menu("Game Play");
		Menu themes = new Menu("Themes");
		Menu options = new Menu("Options");
		MenuItem reverse = new MenuItem("Reverse Move");
		MenuItem themeOne = new MenuItem("Dark");
		MenuItem themeTwo = new MenuItem("Violet");
		MenuItem themeThree = new MenuItem("Light");
		MenuItem howToPlay = new MenuItem("How to Play");
		MenuItem newGame = new MenuItem("New Game");
		MenuItem exit = new MenuItem("Exit");

		gamePlay.getItems().addAll(reverse);
		themes.getItems().addAll(themeOne, themeTwo, themeThree);
		options.getItems().addAll(howToPlay, newGame, exit);

		MenuOptions.getMenus().addAll(gamePlay, themes, options);

		reverse.setOnAction(actionEvent -> UndoMove());
		newGame.setOnAction(actionEvent -> ResetGame());
		howToPlay.setOnAction(MenuPopUps);
		exit.setOnAction(actionEvent -> System.exit(0));

		themeOne.setOnAction(actionEvent -> FirstTheme());
		themeTwo.setOnAction(actionEvent ->  SecTheme());
		themeThree.setOnAction(actionEvent ->  ThirdTheme());

		GameRoot = new VBox(20, MenuOptions, GameGrid, txt);
		GameRoot.setAlignment(Pos.TOP_CENTER);
		GameRoot.setStyle("-fx-background-color: #373737");
		return new Scene(GameRoot, 700, 550);
	}
}
