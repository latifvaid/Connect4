import javafx.scene.control.Button;
import javafx.scene.shape.Circle;

public class GameButton extends Button {
    private int NumRows;
    private int NumCols;
    private boolean CheckClicked;
    private int GamePlayer;
    //setting up board elements
    GameButton(int Rows, int COLS) {
        GamePlayer = 0;
        NumRows = Rows;
        NumCols = COLS;
        getStyleClass().clear();
        setStyle("-fx-background-color:grey;");
        setMinSize(70, 70);
    }
    //helper functions
    public int getNumRow() {
        return NumRows;
    }
    public int getNumCol() {
        return NumCols;
    }
    public void SetCheckClicked(boolean value) {
        CheckClicked = value;
    }
    public boolean GetCheckClicked() {
        return CheckClicked;
    }
    public int getPlayer() {
        return GamePlayer;
    }
    public void SetPlayers(int Player, String Color) {
        this.GamePlayer = Player;
        this.getStyleClass().clear();
        this.setStyle("-fx-background-color:" + Color + ";");
    }
}
